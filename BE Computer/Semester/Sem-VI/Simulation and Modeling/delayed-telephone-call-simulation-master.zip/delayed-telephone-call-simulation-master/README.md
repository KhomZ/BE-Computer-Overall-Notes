
# Delayed-Telephone-Call-Simulation
I created this project during my sixth semester as a project work for the course Simulation and Modelling
